##Example of how to add X10_LIB in CMAKELists.txt



include_directories(
 include
  ${catkin_INCLUDE_DIRS}
  RmdApiSerial/src/x10/include
)

add_subdirectory(RmdApiSerial)


add_executable(example_node src/example.cpp)
target_link_libraries(example_node ${catkin_LIBRARIES} X10_LIB )
target_include_directories(example_node PUBLIC ${catkin_INCLUDE_DIRS} X10_LIB)
